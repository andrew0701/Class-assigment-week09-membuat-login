﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        Form1 form1;
        public Form3(Form1 _Form1)
        {
            InitializeComponent();
            form1 = _Form1;
        }

        private void button_add_Click(object sender, EventArgs e)
        {

            textBox_password_add.PasswordChar = '*';
            textBox_confirm_add.PasswordChar= '*';
            if (textBox_password_add.Text != textBox_confirm_add.Text)
            {
                MessageBox.Show("Password Not Match");
            }
            else
            {
                bool benar = false;
                for (int i = 0; i < Form1.username.Count; i++)
                {
                    if (textBox_username_add.Text == Form1.username[i])
                    {
                        benar = false;
                        
                    }
                    else
                    {
                        benar = true;
                        
                    }
                }
                if (benar == true)
                {
                    MessageBox.Show("User Added!");
                    form1.addDataUser(textBox_username_add.Text, textBox_password_add.Text);
                    this.Hide();
                }
                else if (benar == false)
                {
                    MessageBox.Show("User already Exist");
                }
            }
        }
    }
}

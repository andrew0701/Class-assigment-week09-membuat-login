﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        Form1 formLogin;
        string namaa = "";
        public Form2(Form1 formLogin,string nama)
        {
            InitializeComponent();
            this.formLogin = formLogin;
            namaa = nama;
          
        }
        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(formLogin);
            form3.MdiParent = this;
            form3.Show();

        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = namaa;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = DateTime.Now.ToString("ddd, dd - MM - yyy HM:mm:ss");
            statusStrip1.Update();
        }

    }
}

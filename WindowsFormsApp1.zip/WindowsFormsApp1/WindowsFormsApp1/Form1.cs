﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //public Form1 form1=new Form1();
        public static List <string> username = new List<string> ();
        public static List <string> password = new List<string> ();
        public static string simpan = "";
        public Form1()
        {
            InitializeComponent();
            username.Add("admin");
            password.Add("admin");
            //MessageBox.Show(username.Count.ToString());
        }

        private void button_login_Click(object sender, EventArgs e)
        {
            textBox_password.PasswordChar = '*';
            bool benar = false;
            for (int i = 0;  i < username.Count; i++) 
            {
                if(textBox_password.Text == password[i] && textBox_username.Text == username [i]) 
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                Form2 form2 = new Form2(this,textBox_username.Text);
                form2.ShowDialog();
                this.Hide();
            }
            else if (benar == false)
            {
                MessageBox.Show("Username or Password is not correct");
            }
            simpan = textBox_username.Text;
        }

        public void addDataUser (string user, string pass)
        {
            username.Add(user);
            password.Add(pass);
        }
    }
}

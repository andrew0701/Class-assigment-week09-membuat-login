﻿namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_username_add = new System.Windows.Forms.Label();
            this.label_password_add = new System.Windows.Forms.Label();
            this.label_Confirm_add = new System.Windows.Forms.Label();
            this.textBox_username_add = new System.Windows.Forms.TextBox();
            this.textBox_password_add = new System.Windows.Forms.TextBox();
            this.textBox_confirm_add = new System.Windows.Forms.TextBox();
            this.button_add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_username_add
            // 
            this.label_username_add.AutoSize = true;
            this.label_username_add.Location = new System.Drawing.Point(88, 104);
            this.label_username_add.Name = "label_username_add";
            this.label_username_add.Size = new System.Drawing.Size(110, 25);
            this.label_username_add.TabIndex = 0;
            this.label_username_add.Text = "Username";
            // 
            // label_password_add
            // 
            this.label_password_add.AutoSize = true;
            this.label_password_add.Location = new System.Drawing.Point(92, 164);
            this.label_password_add.Name = "label_password_add";
            this.label_password_add.Size = new System.Drawing.Size(106, 25);
            this.label_password_add.TabIndex = 1;
            this.label_password_add.Text = "Password";
            // 
            // label_Confirm_add
            // 
            this.label_Confirm_add.AutoSize = true;
            this.label_Confirm_add.Location = new System.Drawing.Point(12, 224);
            this.label_Confirm_add.Name = "label_Confirm_add";
            this.label_Confirm_add.Size = new System.Drawing.Size(186, 25);
            this.label_Confirm_add.TabIndex = 2;
            this.label_Confirm_add.Text = "Confirm Password";
            // 
            // textBox_username_add
            // 
            this.textBox_username_add.Location = new System.Drawing.Point(242, 104);
            this.textBox_username_add.Name = "textBox_username_add";
            this.textBox_username_add.Size = new System.Drawing.Size(241, 31);
            this.textBox_username_add.TabIndex = 3;
            // 
            // textBox_password_add
            // 
            this.textBox_password_add.Location = new System.Drawing.Point(242, 161);
            this.textBox_password_add.Name = "textBox_password_add";
            this.textBox_password_add.Size = new System.Drawing.Size(241, 31);
            this.textBox_password_add.TabIndex = 4;
            // 
            // textBox_confirm_add
            // 
            this.textBox_confirm_add.Location = new System.Drawing.Point(242, 224);
            this.textBox_confirm_add.Name = "textBox_confirm_add";
            this.textBox_confirm_add.Size = new System.Drawing.Size(241, 31);
            this.textBox_confirm_add.TabIndex = 5;
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(242, 288);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(144, 60);
            this.button_add.TabIndex = 6;
            this.button_add.Text = "Add User";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_add);
            this.Controls.Add(this.textBox_confirm_add);
            this.Controls.Add(this.textBox_password_add);
            this.Controls.Add(this.textBox_username_add);
            this.Controls.Add(this.label_Confirm_add);
            this.Controls.Add(this.label_password_add);
            this.Controls.Add(this.label_username_add);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_username_add;
        private System.Windows.Forms.Label label_password_add;
        private System.Windows.Forms.Label label_Confirm_add;
        private System.Windows.Forms.TextBox textBox_username_add;
        private System.Windows.Forms.TextBox textBox_password_add;
        private System.Windows.Forms.TextBox textBox_confirm_add;
        private System.Windows.Forms.Button button_add;
    }
}